package com.shishir;

//Only in preview mode
public class InstanceOf {
    public static void main(String args[]){
        Number num = 1.2;

        //Before
        if(num instanceof Integer) {
            Integer intVal = (Integer) num;
            System.out.println(intVal);
        }

        //After
        if(num instanceof Integer intVal) {
            System.out.println(intVal);
        }
    }
}
