package com.shishir;

public class Case {
    public  static  void main(String args[]){
        int x = 10;

        int y = switch (x){
          case 10,20,30 -> 100;
          case 40,50 -> 200;
            default -> 300;
        };

        y = switch (x){
            case 10,20,30 -> 100;
            case 40,50 -> 200;
            default -> throw new RuntimeException();
        };

        y = switch (x){
            case 10,20,30:  yield 100;
            case 40,50: yield 200;
            default: throw new RuntimeException();
        };
    }
}
