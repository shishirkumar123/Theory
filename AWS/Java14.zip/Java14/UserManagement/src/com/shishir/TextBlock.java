package com.shishir;

//Only in preview mode
public class TextBlock {
    public static void main(String args[]){
        System.out.println("""
                india
                is
                my
                country""");
    }
}
