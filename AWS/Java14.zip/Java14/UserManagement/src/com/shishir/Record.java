package com.shishir;

import java.io.Serializable;

public class Record{
    public static void main(String args[]){
        var p1 = new Person("John", "Doe");
        System.out.println("My name is " + p1.fName() + " " + p1.lName());
    }

}
//Records are like lombok
//Record can't extended anything, but can implement.
//Record cant be abstract
record Person(String fName, String lName) implements Serializable {

}

//record Employee extends Person{ //record cant be extended
//
//}
