package com.shishir.springoauthclient.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.web.context.request.RequestContextListener;
import org.springframework.web.servlet.config.annotation.DefaultServletHandlerConfigurer;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

public class WebConfig extends WebMvcConfigurerAdapter{
	@Override
	public void configureDefaultServletHandling(DefaultServletHandlerConfigurer defaultServletHandlerConfigurer) {
		defaultServletHandlerConfigurer.enable();
	}

	@Override
	public void addViewControllers(ViewControllerRegistry viewControllerRegistry) {
		super.addViewControllers(viewControllerRegistry);
		
		viewControllerRegistry.addViewController("/")
								.setViewName("forward:/index");
		
		viewControllerRegistry.addViewController("/index");
		viewControllerRegistry.addViewController("/secure");
	}
	
	@Override
	public void addResourceHandlers(ResourceHandlerRegistry resourceHandlerRegistry) {
		resourceHandlerRegistry.addResourceHandler("/resources/**")
								.addResourceLocations("/resources/");
	}
	
	@Bean
	public RequestContextListener requestContextListener() {
		return new RequestContextListener(); 
	}
	
	@Bean
	public static PropertySourcesPlaceholderConfigurer placeholderConfigurer() {
		return new PropertySourcesPlaceholderConfigurer();
	}
}
